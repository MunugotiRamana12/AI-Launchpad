import os
import csv
import io
import sqlite3
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, Response

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key-before-public-deployment")
DB_PATH = os.environ.get("DB_PATH", "registrations.db")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "LaunchPad@2026")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS registrations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                college TEXT NOT NULL,
                branch TEXT NOT NULL,
                graduation_year TEXT NOT NULL,
                referral_code TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                UNIQUE(email)
            )
        """)

def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("admin_logged_in"):
            return redirect(url_for("admin_login"))
        return view(*args, **kwargs)
    return wrapped

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/register", methods=["POST"])
def register():
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip().lower()
    college = request.form.get("college", "").strip()
    branch = request.form.get("branch", "").strip()
    graduation_year = request.form.get("graduation_year", "").strip()
    referral_code = request.form.get("referral_code", "").strip().upper()

    if not all([name, email, college, branch, graduation_year]):
        flash("Please fill all required fields.", "error")
        return redirect(url_for("home") + "#register")

    if "@" not in email or "." not in email.split("@")[-1]:
        flash("Please enter a valid email address.", "error")
        return redirect(url_for("home") + "#register")

    try:
        with get_db() as conn:
            conn.execute("""
                INSERT INTO registrations
                (name, email, college, branch, graduation_year, referral_code, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (name, email, college, branch, graduation_year, referral_code,
                  datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")))
        return render_template("success.html", name=name)
    except sqlite3.IntegrityError:
        flash("This email is already registered. Use another email or contact the workshop team.", "error")
        return redirect(url_for("home") + "#register")

@app.route("/admin", methods=["GET", "POST"])
def admin_login():
    if session.get("admin_logged_in"):
        return redirect(url_for("admin_dashboard"))
    if request.method == "POST":
        password = request.form.get("password", "")
        if password == ADMIN_PASSWORD:
            session["admin_logged_in"] = True
            return redirect(url_for("admin_dashboard"))
        flash("Incorrect password.", "error")
    return render_template("admin_login.html")

@app.route("/admin/dashboard")
@admin_required
def admin_dashboard():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM registrations ORDER BY id DESC").fetchall()
        total = conn.execute("SELECT COUNT(*) FROM registrations").fetchone()[0]
        today = datetime.utcnow().strftime("%Y-%m-%d")
        today_count = conn.execute(
            "SELECT COUNT(*) FROM registrations WHERE substr(created_at, 1, 10) = ?",
            (today,)
        ).fetchone()[0]
    return render_template("admin_dashboard.html", rows=rows, total=total, today_count=today_count)

@app.route("/admin/export.csv")
@admin_required
def export_csv():
    with get_db() as conn:
        rows = conn.execute("""
            SELECT id, name, email, college, branch, graduation_year, referral_code, created_at
            FROM registrations ORDER BY id DESC
        """).fetchall()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "Name", "Email", "College", "Branch", "Graduation Year", "Referral Code", "Registered At"])
    for row in rows:
        writer.writerow(list(row))
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=student_registrations.csv"}
    )

@app.route("/admin/logout")
def admin_logout():
    session.clear()
    return redirect(url_for("admin_login"))

@app.route("/health")
def health():
    return {"status": "ok"}

init_db()

if __name__ == "__main__":
    app.run(debug=True)
