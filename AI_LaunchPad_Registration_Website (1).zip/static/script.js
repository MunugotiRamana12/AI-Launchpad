const ideas = {
  study: "AI Study Buddy: a tool that turns a topic into a simple explanation and a short quiz.",
  health: "Healthy Habit Helper: a chatbot that shares general wellbeing reminders and habit-tracking ideas.",
  career: "Interview Practice Coach: an app that generates beginner interview questions and gives structured practice tips.",
  environment: "Smart Waste Sorter: a prototype that classifies common waste items and suggests recycling steps.",
  business: "Small-Shop FAQ Assistant: a chatbot that answers common questions about a shop's products and opening hours."
};
const button = document.getElementById("ideaButton");
if (button) button.addEventListener("click", () => {
  const interest = document.getElementById("interest").value;
  document.getElementById("ideaResult").textContent = ideas[interest] || "Choose an interest to see an idea.";
});
