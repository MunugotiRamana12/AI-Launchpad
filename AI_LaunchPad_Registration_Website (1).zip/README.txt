AI LaunchPad — Growth Challenge prototype
==========================================

WHAT THIS APP DOES
- Public workshop landing page
- Interactive AI project idea finder
- Student registration form
- Saves submissions to a SQLite database
- Password-protected admin dashboard at /admin
- CSV export from the admin dashboard

RUN LOCALLY (Windows)
1. Install Python 3.10 or newer from python.org if not already installed.
2. Extract this ZIP.
3. Open the extracted folder in VS Code.
4. Open Terminal > New Terminal.
5. Run:
   py -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   python app.py
6. Open http://127.0.0.1:5000 in your browser.
7. Submit a test registration.
8. Open http://127.0.0.1:5000/admin
   Demo admin password: LaunchPad@2026
9. In the admin dashboard, view registrations or click Export CSV.

IMPORTANT ABOUT REGISTRATION DATA
- This demo stores submissions in registrations.db on the server where the app runs.
- It does NOT automatically email the owner and it is NOT connected to Google Sheets.
- The owner checks details at /admin and can export CSV.
- Use only test details during the challenge demo.
- The supplied NxtWave Google Form is for submitting your Growth Challenge work, not for student registrations.
- This is a prototype and does not confirm an official NxtWave workshop, date, or certificate.

PUBLIC DEPLOYMENT
This app needs a Python-capable host (not GitHub Pages alone). Before deploying:
- Set ADMIN_PASSWORD to a strong private password.
- Set SECRET_KEY to a long random secret.
- Use a host with persistent storage for SQLite, or configure a managed database. Some free hosts erase local files/restart containers, which can lose registrations.
- If you want real student data, publish a privacy notice and get appropriate consent. For the assignment, keep it a simulation and use dummy/test data.
- The default demo password is visible in this README and must not be used on a public deployment.

FILES
app.py                  Flask routes and database logic
requirements.txt        Python dependencies
Procfile                Start command for compatible hosts
templates/              Page templates
static/                 CSS and JavaScript
